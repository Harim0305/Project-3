import pandas as pd
import numpy as np

df = pd.read_csv('C:/Users/LG PC/Section3/movie/movie.csv')

# 열 이름 변경
df.rename(columns={'0':'Date', '1':'movieNm', '2':'movieCd', '3':'audiCnt', 
                   '4':'audiInten', '5':'audiChange', '6':'audiAcc', '7':'openDt', 
                   '8':'salesAmt', '9':'salesShare', '10':'salesInten', '11':'salesChange', 
                   '12':'salesAcc', '13':'scrnCnt', '14':'showCnt','15':'rank', 
                   '16':'rankInten', '17':'rankOldAndNew'}, inplace=True)

# date 컬럼 정리
date_list = df['Date'].str.split('~')
df['date'] = date_list.str.get(0)
df = df.drop(['Date'], axis=1)
df = df.sort_values('date', ascending=False)

# 이상치 제거
df = df.iloc[:5670]
df.tail()

# 열 순서 변경
df = df[['date', 'movieNm', 'movieCd', 'audiCnt', 'audiInten', 'audiChange', 'audiAcc', 'openDt',
         'salesAmt', 'salesShare', 'salesInten', 'salesChange', 'salesAcc', 'scrnCnt', 'showCnt', 
         'rank', 'rankInten', 'rankOldAndNew']]
df = df.reset_index(drop=True)

# 필요없는 열 제거
df = df.drop(['movieCd'], axis=1)

# 박스오피스 날짜별 1위 데이터만 남기기
df = df.sort_values('rank', ascending=True)
df = df.drop_duplicates(['date'], keep='first')
df = df.reset_index(drop=True)

# target은 rankOldAndNew -> 랭킹 진입 오래 유지 되는지 알아보기
df['rankOldAndNew'] = df['rankOldAndNew'].replace({'NEW': 0, 'OLD':1}).astype(np.uint8)

# 데이터 분리
X = df.drop(['rankOldAndNew', 'openDt', 'movieNm', 'date', 'audiInten', 'audiChange', 'audiAcc', 'salesShare', 
             'salesInten', 'salesChange', 'salesAcc', 'rankInten', 'rank'], axis=1)
y = df['rankOldAndNew']

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, random_state=42)
X_train.shape, X_test.shape, y_train.shape, y_test.shape

# 모델링
from imblearn.over_sampling import SMOTE
over = SMOTE()
X_train, y_train = over.fit_resample(X_train, y_train.ravel())

# random forest, 교차 검증
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
rf_pipeline = Pipeline(steps = [('scale', StandardScaler()),
                                ('RF', RandomForestClassifier(random_state=42))])

from sklearn.model_selection import cross_val_score
rf_cv = cross_val_score(rf_pipeline, X_train, y_train, cv=10, scoring='f1')

from sklearn.metrics import confusion_matrix
from sklearn.metrics import f1_score

rf_pipeline.fit(X_train, y_train)

rf_pred = rf_pipeline.predict(X_test)

rf_cm = confusion_matrix(y_test, rf_pred)

rf_f1 = f1_score(y_test, rf_pred)

rfc = RandomForestClassifier(max_features=3, n_estimators=1500, bootstrap=True)
rfc.fit(X_train, y_train)
rfc_pred = rfc.predict(X_test)

from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score

print(classification_report(y_test, rfc_pred))
print('Accurac Score: ', accuracy_score(y_test, rfc_pred))
print('F1 Score: ', f1_score(y_test, rfc_pred))

import pickle

pickle.dump(rfc, open('model.pkl', 'wb'))