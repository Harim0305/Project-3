import sqlite3 as sq3
import pandas as pd
con = sq3.connect('C:/Users/LG PC/Section3/movie/moviedb.db')
cursor = con.cursor()

boxoffice = """SELECT movieNm, COUNT(*) AS cnt
FROM movie_eda me 
GROUP BY movieNm
ORDER BY cnt DESC
limit 10;"""

ranking = """SELECT movieNm, ranking, COUNT(*) AS cnt
FROM movie_eda me 
WHERE ranking = 1
GROUP BY movieNm
ORDER BY cnt DESC
limit 10;"""

openday = """SELECT movieNm, ranking, openDt
FROM movie_eda me 
WHERE ranking = 1
GROUP BY movieNm 
ORDER BY openDt DESC;"""

keep_top = """SELECT movieNm, rankOldAndNew, COUNT(*) AS cnt
FROM movie_eda me 
WHERE rankOldAndNew = 'OLD'
GROUP BY movieNm
ORDER BY cnt DESC
limit 20;"""

total_sales = """SELECT movieNm, ranking, salesAmt
FROM movie_eda me 
WHERE ranking =1
GROUP BY movieNm
ORDER BY salesAmt DESC
limit 10;"""

total_viewers = """SELECT movieNm, ranking, audiCnt
FROM movie_eda me 
WHERE ranking = 1
GROUP BY movieNm 
ORDER BY audiCnt DESC
limit 10;"""

total_screen = """SELECT movieNm, ranking, scrnCnt
FROM movie_eda me 
WHERE ranking = 1
GROUP BY movieNm 
ORDER BY scrnCnt DESC 
limit 10;"""

total_screening = """SELECT movieNm, ranking, showCnt
FROM movie_eda me 
WHERE ranking = 1
GROUP BY movieNm 
ORDER BY showCnt DESC 
limit 10;"""

cursor.execute('SELECT * FROM movie_eda')
cursor.fetchall()


con.commit()
con.close()