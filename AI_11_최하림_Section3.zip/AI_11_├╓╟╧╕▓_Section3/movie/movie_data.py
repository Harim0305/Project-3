import pandas as pd
import requests
import json

url = "https://kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json?key=db7610f7bd4859e748427d166bf536ab&targetDt=20210316"

res = requests.get(url)
text = res.text

d = json.loads(text)
# print(d)

movie_list = []

for b in d['boxOfficeResult']['dailyBoxOfficeList']:
    movie_list.append([b['rank'], b['movieNm'], b['audiCnt']])

data = pd.DataFrame(movie_list)
data.to_csv("movie_list.txt", mode='w', encoding='utf-8', index=False)