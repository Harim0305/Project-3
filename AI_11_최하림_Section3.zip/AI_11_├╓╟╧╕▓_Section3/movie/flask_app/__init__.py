from flask import Flask, render_template, request, jsonify
import pickle
import numpy as np

app = Flask(__name__)

@app.route('/')
@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/search')
def search():
    return render_template('search.html')

@app.route('/predict', methods=['POST'])
def predict():
    return 200

if __name__ == '__main__':
    modelfile = 'model.pkl'
    model = pickle.load(open(modelfile, 'rb'))
    app.run(debut=True)